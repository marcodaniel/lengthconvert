----------------------------------------------------------------
The lengthconvert package --- Convert a length to an other unit.
E-mail: marco.daniel@mada-nada.de
Released under the LaTeX Project Public License v1.3c or later
See http://www.latex-project.org/lppl.txt
----------------------------------------------------------------

Requires expl3

